/* Chord Bonang — shell lokal offline-first. Data lagu diunduh dari JSON publik. */
(function () {
    "use strict";

    const DATA_URL = "https://raw.githubusercontent.com/hinomiyakael-glitch/chord-bonang-data/refs/heads/main/songs.json";
    const DB_NAME = "chordbonang";
    const DB_VERSION = 1;
    const STORE_SONGS = "songs";
    const STORE_META = "meta";
    const STORAGE_PREFIX = "chordbonang.";
    const MOBILE_MEDIA_QUERY = "(max-width: 768px)";
    const DESKTOP_FONT_PX = 15;
    const MOBILE_FONT_PX = 11;
    const MIN_FONT_PX = 9;
    const MAX_FONT_PX = 28;
    const SCROLL_SYNC_THRESHOLD = 2;
    const SPEED_PX_PER_SEC = { 1: 5, 2: 11, 3: 20, 4: 34, 5: 55 };
    const NOTES_SHARP = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
    const FLAT_TO_INDEX = { DB: 1, EB: 3, GB: 6, AB: 8, BB: 10 };

    const $ = (id) => document.getElementById(id);

    let dbPromise = null;
    let songs = [];
    let meta = null;
    let currentSong = null;
    let rawText = "";
    let transposeSteps = 0;
    let fontSizePx = MOBILE_FONT_PX;
    let speed = 1;
    let isScrolling = false;
    let exactScrollY = 0;
    let lastFrameTime = null;
    let rafId = null;
    let wakeLockSentinel = null;
    let syncing = false;
    let lastAutoCheck = 0;
    const AUTO_CHECK_INTERVAL_MS = 5 * 60 * 1000;

    /* ---------- IndexedDB ---------- */

    function openDB() {
        if (dbPromise) return dbPromise;
        dbPromise = new Promise((resolve, reject) => {
            if (!window.indexedDB) {
                reject(new Error("IndexedDB tidak tersedia"));
                return;
            }
            const req = indexedDB.open(DB_NAME, DB_VERSION);
            req.onupgradeneeded = () => {
                const db = req.result;
                if (!db.objectStoreNames.contains(STORE_SONGS)) {
                    db.createObjectStore(STORE_SONGS, { keyPath: "id" });
                }
                if (!db.objectStoreNames.contains(STORE_META)) {
                    db.createObjectStore(STORE_META, { keyPath: "key" });
                }
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error || new Error("Gagal membuka cache"));
        });
        return dbPromise;
    }

    function txDone(tx) {
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error || new Error("Transaksi cache gagal"));
            tx.onabort = () => reject(tx.error || new Error("Transaksi cache dibatalkan"));
        });
    }

    async function getAllSongs() {
        const db = await openDB();
        const tx = db.transaction(STORE_SONGS, "readonly");
        const req = tx.objectStore(STORE_SONGS).getAll();
        return new Promise((resolve, reject) => {
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
        });
    }

    async function saveSongs(list) {
        const db = await openDB();
        // durability strict: data di-flush ke disk sebelum transaksi selesai,
        // sehingga cache tidak hilang jika app langsung ditutup/di-kill.
        const tx = db.transaction(STORE_SONGS, "readwrite", { durability: "strict" });
        const store = tx.objectStore(STORE_SONGS);
        store.clear();
        list.forEach((song) => store.put(song));
        await txDone(tx);
    }

    async function getMeta() {
        const db = await openDB();
        const tx = db.transaction(STORE_META, "readonly");
        const req = tx.objectStore(STORE_META).get("state");
        return new Promise((resolve, reject) => {
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error);
        });
    }

    async function saveMeta(state) {
        const db = await openDB();
        const tx = db.transaction(STORE_META, "readwrite", { durability: "strict" });
        tx.objectStore(STORE_META).put(Object.assign({ key: "state" }, state));
        await txDone(tx);
    }

    /* Simpan daftar lagu + meta dalam SATU transaksi agar tidak setengah jadi. */
    async function saveData(list, state) {
        const db = await openDB();
        const tx = db.transaction([STORE_SONGS, STORE_META], "readwrite", { durability: "strict" });
        const songStore = tx.objectStore(STORE_SONGS);
        songStore.clear();
        list.forEach((song) => songStore.put(song));
        tx.objectStore(STORE_META).put(Object.assign({ key: "state" }, state));
        await txDone(tx);
    }

    /* Cadangan data di localStorage: dipakai jika IndexedDB kosong/rusak
       (mis. app dimatikan paksa saat menulis cache). */
    const MIRROR_KEY = "songs-mirror.v1";

    function saveMirror(version, count, list) {
        try {
            localStorage.setItem(STORAGE_PREFIX + MIRROR_KEY, JSON.stringify({
                version: version,
                count: count,
                savedAt: Date.now(),
                songs: list
            }));
        } catch (_) {}
    }

    function loadMirror() {
        try {
            const raw = localStorage.getItem(STORAGE_PREFIX + MIRROR_KEY);
            if (!raw) return null;
            const parsed = JSON.parse(raw);
            if (!parsed || !Array.isArray(parsed.songs) || !parsed.songs.length) return null;
            return parsed;
        } catch (_) {
            return null;
        }
    }

    /* ---------- Penyimpanan setelan ---------- */

    function readStoredNumber(key) {
        try {
            const raw = localStorage.getItem(STORAGE_PREFIX + key);
            if (raw === null || raw.trim() === "") return null;
            const value = Number(raw);
            return Number.isFinite(value) ? value : null;
        } catch (_) {
            return null;
        }
    }

    function writeStored(key, value) {
        try {
            localStorage.setItem(STORAGE_PREFIX + key, String(value));
        } catch (_) {}
    }

    function isMobileLayout() {
        return window.matchMedia && window.matchMedia(MOBILE_MEDIA_QUERY).matches;
    }

    function fontKey() {
        return isMobileLayout() ? "fontSize.mobile" : "fontSize.desktop";
    }

    function clamp(value, min, max) {
        return Math.min(max, Math.max(min, value));
    }

    function applyStoredFont() {
        const stored = readStoredNumber(fontKey());
        fontSizePx = stored === null
            ? (isMobileLayout() ? MOBILE_FONT_PX : DESKTOP_FONT_PX)
            : clamp(Math.round(stored), MIN_FONT_PX, MAX_FONT_PX);
    }

    /* ---------- Daftar lagu ---------- */

    function sortSongs(list) {
        return list.slice().sort((a, b) =>
            String(a.title || a.id).localeCompare(String(b.title || b.id), undefined, { sensitivity: "base" })
        );
    }

    function renderList() {
        const keyword = ($("search").value || "").trim().toLowerCase();
        const filtered = keyword
            ? songs.filter((song) =>
                  (song.title + " " + song.artist + " " + (song.content || "")).toLowerCase().includes(keyword)
              )
            : songs;

        const listEl = $("songList");
        listEl.innerHTML = "";
        filtered.forEach((song) => {
            const li = document.createElement("li");
            const link = document.createElement("a");
            link.className = "song-link";
            link.href = "#/song/" + encodeURIComponent(song.id);

            const title = document.createElement("span");
            title.className = "song-title";
            title.textContent = song.title || song.id;

            const artist = document.createElement("span");
            artist.className = "song-artist";
            artist.textContent = song.artist || "";

            link.appendChild(title);
            if (song.artist) link.appendChild(artist);
            li.appendChild(link);
            listEl.appendChild(li);
        });

        const empty = $("emptyState");
        if (filtered.length) {
            empty.hidden = true;
        } else {
            empty.hidden = false;
            empty.textContent = songs.length
                ? "Tidak ada lagu yang cocok."
                : "Belum ada lagu tersimpan. Sambungkan internet lalu tekan \u201cUpdate Lagu\u201d.";
        }
        $("songCount").textContent = songs.length + " lagu";
    }

    /* ---------- Transpose & render chord ---------- */

    function escapeHtml(str) {
        return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    function transposeChordToken(token) {
        return token.replace(/^([A-G])(#|b)?(.*)$/i, (_, root, acc, suffix) => {
            const upperRoot = root.toUpperCase();
            const accClean = (acc || "").toLowerCase();
            let idx = NOTES_SHARP.indexOf(upperRoot);
            if (accClean === "#") idx = (idx + 1) % 12;
            if (accClean === "b") {
                const flatKey = upperRoot + "B";
                idx = FLAT_TO_INDEX[flatKey] !== undefined ? FLAT_TO_INDEX[flatKey] : (idx + 11) % 12;
            }
            const nextIdx = (((idx + transposeSteps) % 12) + 12) % 12;
            return NOTES_SHARP[nextIdx] + suffix;
        });
    }

    function renderChords() {
        const output = $("chordOutput");
        const lines = rawText.split("\n");
        const chordRegex = /\b[A-G](#|b)?(maj7|maj|min|m7|m|dim|aug|sus[24]?|add[0-9]+|[0-9]+)?(\/[A-G](#|b)?)?\b/g;

        const rendered = lines.map((line) => {
            const trimmed = line.trim();
            const tokens = trimmed ? trimmed.split(/\s+/) : [];
            const chordLike = tokens.filter((token) =>
                /^[A-G](#|b)?(maj7|maj|min|m7|m|dim|aug|sus[24]?|add[0-9]+|[0-9]+)?(\/[A-G](#|b)?)?$/.test(token)
            );
            const isChordLine = chordLike.length > 0 && chordLike.length >= tokens.length * 0.6;
            if (!isChordLine) return escapeHtml(line);
            return line.replace(chordRegex, (match) =>
                '<span class="chord-token">' + escapeHtml(transposeChordToken(match)) + "</span>"
            );
        });

        output.innerHTML = rendered.join("\n");
        output.style.fontSize = fontSizePx + "px";
        $("transBadge").textContent = "Key: " + (transposeSteps > 0 ? "+" + transposeSteps : transposeSteps);
    }

    /* ---------- Autoscroll ---------- */

    function updateScrollLabel() {
        const mobile = isMobileLayout();
        $("btnScroll").textContent = mobile
            ? (isScrolling ? "Stop" : "Scroll")
            : (isScrolling ? "Auto Scroll: On" : "Auto Scroll: Off");
        $("btnScroll").classList.toggle("active", isScrolling);
        document.body.classList.toggle("focus-mode", isScrolling && mobile);
    }

    function stopScroll() {
        isScrolling = false;
        if (rafId) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
        updateScrollLabel();
    }

    function scrollStep(timestamp) {
        if (!isScrolling) return;
        const currentY = window.scrollY;
        if (Math.abs(currentY - exactScrollY) > SCROLL_SYNC_THRESHOLD) {
            exactScrollY = currentY;
            lastFrameTime = null;
        }
        if (lastFrameTime !== null) {
            const dt = (timestamp - lastFrameTime) / 1000;
            exactScrollY += (SPEED_PX_PER_SEC[speed] || SPEED_PX_PER_SEC[1]) * dt;
            window.scrollTo(0, exactScrollY);
        }
        lastFrameTime = timestamp;
        rafId = requestAnimationFrame(scrollStep);
    }

    function toggleScroll() {
        isScrolling = !isScrolling;
        updateScrollLabel();
        if (isScrolling) {
            exactScrollY = window.scrollY;
            lastFrameTime = null;
            rafId = requestAnimationFrame(scrollStep);
        } else if (rafId) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
    }

    function setSpeed(delta) {
        speed = clamp(speed + delta, 1, 5);
        $("speedLabel").textContent = String(speed);
        writeStored("speed", speed);
        if (isScrolling) {
            exactScrollY = window.scrollY;
            lastFrameTime = null;
        }
    }

    function setFontSize(next) {
        fontSizePx = clamp(next, MIN_FONT_PX, MAX_FONT_PX);
        writeStored(fontKey(), fontSizePx);
        $("chordOutput").style.fontSize = fontSizePx + "px";
    }

    async function toggleWakeLock() {
        const button = $("btnWakeLock");
        if (!("wakeLock" in navigator)) {
            button.textContent = "Layar Nyala: N/A";
            return;
        }
        if (wakeLockSentinel) {
            await wakeLockSentinel.release();
            wakeLockSentinel = null;
            button.classList.remove("active");
            button.textContent = "Layar Nyala: Off";
            return;
        }
        try {
            wakeLockSentinel = await navigator.wakeLock.request("screen");
            button.classList.add("active");
            button.textContent = "Layar Nyala: On";
            wakeLockSentinel.addEventListener("release", () => {
                wakeLockSentinel = null;
                button.classList.remove("active");
                button.textContent = "Layar Nyala: Off";
            });
        } catch (_) {
            button.textContent = "Layar Nyala: Off";
        }
    }

    /* ---------- Routing ---------- */

    function showList() {
        currentSong = null;
        stopScroll();
        $("detailView").hidden = true;
        $("listView").hidden = false;
        document.title = "Chord Bonang";
        window.scrollTo(0, 0);
    }

    function showDetail(song) {
        currentSong = song;
        rawText = song.content || "";
        $("songTitle").textContent = song.title || song.id;
        $("songArtist").textContent = song.artist || "";
        $("listView").hidden = true;
        $("detailView").hidden = false;
        document.title = (song.title || "Chord") + " \u2014 Chord Bonang";

        const storedTranspose = readStoredNumber("transpose." + encodeURIComponent(song.id));
        transposeSteps = storedTranspose === null ? 0 : clamp(Math.trunc(storedTranspose), -99, 99);
        applyStoredFont();
        const storedSpeed = readStoredNumber("speed");
        speed = storedSpeed === null ? 1 : clamp(Math.round(storedSpeed), 1, 5);
        $("speedLabel").textContent = String(speed);

        stopScroll();
        renderChords();
        window.scrollTo(0, 0);
    }

    function route() {
        const match = location.hash.match(/^#\/song\/(.+)$/);
        if (!match) {
            showList();
            return;
        }
        const id = decodeURIComponent(match[1]);
        const song = songs.find((item) => item.id === id || item.filename === id);
        if (!song) {
            location.replace("#/");
            return;
        }
        showDetail(song);
    }

    /* ---------- Update data lagu (JSON publik) ---------- */

    function timeAgo(timestamp) {
        if (!timestamp) return "belum pernah";
        const diff = Date.now() - timestamp;
        if (diff < 60 * 1000) return "baru saja";
        const minutes = Math.floor(diff / 60000);
        if (minutes < 60) return minutes + " menit lalu";
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return hours + " jam lalu";
        return Math.floor(hours / 24) + " hari lalu";
    }

    function updateSyncBar(tone, message) {
        const dot = $("syncDot");
        const text = $("syncText");
        if (message) {
            dot.className = "dot" + (tone ? " " + tone : "");
            text.textContent = message;
            return;
        }
        if (!navigator.onLine) {
            dot.className = "dot warn";
            text.textContent = "Mode offline \u2022 memakai cache lokal";
            return;
        }
        if (!meta || !meta.count) {
            dot.className = "dot warn";
            text.textContent = "Belum ada lagu di cache lokal";
            return;
        }
        dot.className = "dot ok";
        text.textContent = meta.count + " lagu tersimpan \u2022 sync " + timeAgo(meta.lastSync);
    }

    async function syncNow(manual) {
        if (syncing) return;
        syncing = true;
        const button = $("syncBtn");
        const label = button.textContent;
        button.disabled = true;
        if (manual) {
            button.textContent = "Mengunduh\u2026";
            updateSyncBar("warn", "Mengunduh data lagu\u2026");
        }

        try {
            const res = await fetch(DATA_URL + "?ts=" + Date.now(), { cache: "no-store" });
            if (!res.ok) throw new Error("HTTP " + res.status);
            const data = await res.json();
            if (!data || data.ok === false || !Array.isArray(data.songs)) {
                throw new Error("format JSON tidak valid");
            }

            const unchanged =
                meta && meta.version && data.version === meta.version && songs.length === data.songs.length;

            const nextMeta = {
                version: data.version,
                count: Number.isFinite(data.count) ? data.count : data.songs.length,
                lastSync: Date.now()
            };

            if (!unchanged) {
                try {
                    await saveData(data.songs, nextMeta);
                    songs = sortSongs(await getAllSongs());
                } catch (_) {
                    songs = sortSongs(data.songs.slice());
                }
            }

            meta = nextMeta;
            saveMirror(meta.version, meta.count, data.songs);
            try {
                await saveMeta(meta);
            } catch (_) {}
            renderList();
            if (currentSong) {
                const fresh = songs.find((item) => item.id === currentSong.id);
                if (fresh) {
                    currentSong = fresh;
                    rawText = fresh.content || "";
                    renderChords();
                }
            }
            updateSyncBar(
                "ok",
                meta.count + " lagu tersimpan \u2022 update baru saja" +
                    (unchanged ? " (sudah terbaru)" : "")
            );
        } catch (err) {
            if (manual) {
                updateSyncBar(
                    "err",
                    "Gagal update: " + (err && err.message ? err.message : err) + " \u2022 cek koneksi internet"
                );
            } else {
                updateSyncBar();
            }
        } finally {
            syncing = false;
            button.disabled = false;
            button.textContent = label;
        }
    }

    /* Cek update otomatis saat app dibuka / kembali aktif (maks. tiap 5 menit). */
    function autoSync(force) {
        if (syncing) return;
        const now = Date.now();
        if (!force && now - lastAutoCheck < AUTO_CHECK_INTERVAL_MS) return;
        lastAutoCheck = now;
        if (!navigator.onLine) {
            updateSyncBar();
            return;
        }
        syncNow(false);
    }

    /* ---------- Inisialisasi ---------- */

    function bindUi() {
        $("search").addEventListener("input", renderList);
        $("syncBtn").addEventListener("click", () => syncNow(true));

        $("btnTransposeDown").addEventListener("click", () => {
            transposeSteps -= 1;
            if (currentSong) writeStored("transpose." + encodeURIComponent(currentSong.id), transposeSteps);
            renderChords();
        });
        $("btnTransposeUp").addEventListener("click", () => {
            transposeSteps += 1;
            if (currentSong) writeStored("transpose." + encodeURIComponent(currentSong.id), transposeSteps);
            renderChords();
        });
        $("btnFontDown").addEventListener("click", () => setFontSize(fontSizePx - 1));
        $("btnFontUp").addEventListener("click", () => setFontSize(fontSizePx + 1));
        $("btnScroll").addEventListener("click", toggleScroll);
        $("btnSpeedDown").addEventListener("click", () => setSpeed(-1));
        $("btnSpeedUp").addEventListener("click", () => setSpeed(1));
        $("btnWakeLock").addEventListener("click", toggleWakeLock);

        if (window.matchMedia) {
            const media = window.matchMedia(MOBILE_MEDIA_QUERY);
            const onChange = () => {
                if (!currentSong) return;
                applyStoredFont();
                renderChords();
            };
            if (media.addEventListener) media.addEventListener("change", onChange);
            else if (media.addListener) media.addListener(onChange);
        }

        window.addEventListener("online", () => {
            updateSyncBar();
            autoSync(true);
        });
        window.addEventListener("offline", () => updateSyncBar());
        document.addEventListener("visibilitychange", () => {
            if (document.visibilityState === "visible") autoSync(false);
        });
        document.addEventListener("resume", () => autoSync(false));
        window.addEventListener("hashchange", route);
    }

    async function init() {
        bindUi();
        applyStoredFont();
        updateScrollLabel();

        try {
            meta = await getMeta();
            songs = sortSongs(await getAllSongs());
        } catch (_) {
            songs = [];
            meta = null;
        }

        // IndexedDB kosong/rusak (mis. app di-kill saat menulis) -> pulihkan dari mirror.
        if (!songs.length) {
            const mirror = loadMirror();
            if (mirror) {
                songs = sortSongs(mirror.songs.slice());
                try {
                    await saveSongs(mirror.songs);
                } catch (_) {}
            }
        }

        // Meta hilang tapi lagu ada -> susun ulang dari mirror / jumlah lagu.
        if (!meta) {
            const mirror = loadMirror();
            meta = mirror
                ? {
                      version: mirror.version,
                      count: Number.isFinite(mirror.count) ? mirror.count : mirror.songs.length,
                      lastSync: mirror.savedAt
                  }
                : songs.length
                ? { version: null, count: songs.length, lastSync: null }
                : null;
            if (meta) {
                try {
                    await saveMeta(meta);
                } catch (_) {}
            }
        }

        renderList();
        updateSyncBar();
        route();

        autoSync(true);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
