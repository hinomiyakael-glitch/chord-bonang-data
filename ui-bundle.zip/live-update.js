/* Live Update UI (self-hosted, tanpa akun/cloud).
   Jalur data lagu ("Update Lagu" di app.js) sengaja tidak disentuh. */
(function () {
    "use strict";

    const MANIFEST_URL =
        "https://raw.githubusercontent.com/hinomiyakael-glitch/chord-bonang-data/refs/heads/main/ui-bundle.json";
    const LS_KEY = "chordbonang.ui-bundle-id";
    let checking = false;

    function plugin() {
        return window.Capacitor && window.Capacitor.Plugins
            ? window.Capacitor.Plugins.LiveUpdate
            : null;
    }

    async function checkForUiUpdate() {
        const LiveUpdate = plugin();
        if (!LiveUpdate || checking) return; // browser biasa / plugin belum terpasang -> no-op
        checking = true;
        try {
            // Beri sinyal bundle saat ini sudah dipakai (dibutuhkan plugin untuk rollback).
            if (typeof LiveUpdate.ready === "function") {
                await LiveUpdate.ready().catch(() => {});
            }

            const res = await fetch(MANIFEST_URL + "?ts=" + Date.now(), { cache: "no-store" });
            if (!res.ok) return;
            const info = await res.json();
            const bundleId = info.bundleId || info.version;
            if (!bundleId || !info.url) return;

            const applied = localStorage.getItem(LS_KEY);
            if (applied === bundleId) return;

            const current = await LiveUpdate.getCurrentBundle().catch(() => ({ bundleId: null }));
            if (current && current.bundleId === bundleId) {
                localStorage.setItem(LS_KEY, bundleId);
                return;
            }

            // Kalau bundle sudah pernah diunduh, downloadBundle bisa error; tetap lanjut stage.
            await LiveUpdate.downloadBundle({ url: info.url, bundleId: bundleId }).catch(() => {});
            await LiveUpdate.setNextBundle({ bundleId: bundleId });
            localStorage.setItem(LS_KEY, bundleId);

            // Tidak memanggil reload(): IndexedDB dipakai app.js untuk cache lagu.
            // Bundle otomatis aktif saat aplikasi dibuka berikutnya (force-quit + buka).
            console.info("[live-update] UI bundle " + bundleId + " siap dipakai saat aplikasi dibuka lagi.");
        } catch (error) {
            console.warn("[live-update] lewati update UI:", error && error.message ? error.message : error);
        } finally {
            checking = false;
        }
    }

    function schedule() {
        setTimeout(checkForUiUpdate, 1200);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", schedule);
    } else {
        schedule();
    }

    document.addEventListener("visibilitychange", function () {
        if (!document.hidden) schedule();
    });
    window.addEventListener("online", schedule);
})();
